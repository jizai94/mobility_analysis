import React from 'react'
import { render } from 'react-dom'
import { Router, Route, IndexRoute, hashHistory } from 'react-router'
import Layout from '../components/Layout'
import TodayDetails from '../components/TodayDetailsView'
import ApplicationTrend from '../components/ApplicationTrendView'
import TimeAnalysis from '../components/TimeAnalysisView'
import VersionView from '../components/VersionView'
import RegionView from '../components/RegionView'
import BrandView from '../components/BrandView'

/*const UserInfo = (location, callback) => {
	require.ensure([], (require) => {
		callback(null, require('../containers/UserInfo').default, 'UserInfo')
	})
}*/

let routes = <Route path="/" component={ Layout }>
				<IndexRoute component={ TodayDetails }></IndexRoute>
				<Route path="todayDetails" component={ TodayDetails }></Route>
				<Route path="applicationTrend" component={ ApplicationTrend }></Route>
				<Route path="timeAnalysis" component={ TimeAnalysis }></Route>

				<Route path="version" component={ VersionView  }></Route>
				<Route path="region" component={ RegionView }></Route>
				<Route path="brand" component={ BrandView }></Route>
				{/*<Route path="shoppingCart" component={ ShoppingCart }></Route>
				<Route path="userInfo" getComponent={ UserInfo }></Route>*/}
			 </Route>

/*let routesWithJsObj = {
	path: '/',
	component: Layout,
	indexRoute: { component: ShoppingCart },
	childRoutes: [
		{
			path: 'shoppingCart',
			component: ShoppingCart
		},
		{
			path: 'UserInfo',
			component: UserInfo
		}
	]
}*/

export default routes
const getOption1 = () => {
    const option = {
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            bottom: '20',
            data: ['2017-4-26', '2017-4-25']
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '15%',
            containLabel: true
        },
        xAxis: [{
            type: 'category',
            axisTick: {
                // 刻度与标签对齐
                alignWithLabel: true
                    // 隔1个显示1个标签
            },
            boundaryGap: true,
            data: ['0:00', '1:00', '2:00', '3:00', '4:00', '5:00', '6:00', '7:00', '8:00', '9:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '24:00']
        }],
        yAxis: {
            type: 'value',
            axisTick: {
                // 刻度与标签对齐
                alignWithLabel: true
            },
            splitLine: {
                lineStyle: {
                    type: 'dotted'
                }
            },
            axisLine: {
                show: false,
                onZero: false
            },
            axisTick: {
                show: false
            }
        },
        series: [{
            name: '2017-4-26',
            type: 'line',
            smooth: 'true',
            symbol: 'circle',
            symbolSize: 8,
            zlevel: 10,
            itemStyle: {
                normal: {
                    color: 'rgb(0, 153, 204)'
                }
            },
            areaStyle: {
                normal: {
                    color: ['#e2f1f6']
                }
            },
            data: [85445, 85027, 88375, 81497, 115000, 83758, 85445, 85027, 88375, 81497, 90981, 83758]
        }, {
            name: '2017-4-25',
            type: 'line',
            smooth: 'true',
            symbol: 'circle',
            symbolSize: 8,
            itemStyle: {
                normal: {
                    color: 'rgb(204, 204, 204)'
                }
            },
            areaStyle: {
                normal: {
                    color: ['#fafafa']
                }
            },
            data: [88706, 90322, 90298, 85751, 84841, 99496, 88706, 90322, 90298, 85751, 84841, 99496, 88706, 90322, 90298, 85751, 84841, 99496, 88706, 90322, 90298, 85751, 84841, 99496]
        }, ]
    };
    return option;
}


const getOption2 = () => {
    const option = {
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            bottom: '20',
            data: ['2017-4-26', '2017-4-25']
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '15%',
            containLabel: true
        },
        xAxis: [{
            type: 'category',
            axisTick: {
                // 刻度与标签对齐
                alignWithLabel: true
                    // 隔1个显示1个标签
            },
            boundaryGap: true,
            data: ['0:00', '1:00', '2:00', '3:00', '4:00', '5:00', '6:00', '7:00', '8:00', '9:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '24:00']
        }],
        yAxis: {
            type: 'value',
            axisTick: {
                // 刻度与标签对齐
                alignWithLabel: true
            },
            splitLine: {
                lineStyle: {
                    type: 'dotted'
                }
            },
            axisLine: {
                show: false,
                onZero: false
            },
            axisTick: {
                show: false
            }
        },
        series: [{
            name: '2017-4-26',
            type: 'line',
            zlevel: 10,
            symbol: 'circle',
            symbolSize: 8,
            itemStyle: {
                normal: {
                    color: 'rgb(0, 153, 204)'
                }
            },
            areaStyle: {
                normal: {
                    color: ['#e2f1f6']
                }
            },
            data: [4842, 9690, 14412, 19213, 23452, 28110, 32463, 37375, 42036, 46069, 50381, 55206]
        }, {
            name: '2017-4-25',
            type: 'line',
            symbol: 'circle',
            symbolSize: 8,
            itemStyle: {
                normal: {
                    color: 'rgb(204, 204, 204)'
                }
            },
            areaStyle: {
                normal: {
                    color: ['#fafafa']
                }
            },
            data: [4250, 8594, 13491, 17688, 22151, 26816, 30898, 35284, 39349, 44104, 48836, 53613, 58567, 63410, 68259, 72997, 77647, 81903, 86064, 90475, 95678, 101600, 110300, 115670]
        }, ]
    };
    return option;
}

const getOption3 = () => {
    const option = {
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            bottom: '20',
            data: ['活跃用户', '活跃用户(均值)']
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '15%',
            containLabel: true
        },
        xAxis: [{
            type: 'category',
            axisTick: {
                // 刻度与标签对齐
                alignWithLabel: 3
                    // 隔1个显示1个标签
            },
            splitLine: {
                show: true,
                lineStyle: {
                    type: 'solid'
                }
            },
            boundaryGap: false,
            data: ['2017-03-27','2017-03-28','2017-03-29','2017-03-30','2017-03-31',
                   '2017-04-01','2017-04-02','2017-04-03','2017-04-04','2017-04-05',
                   '2017-04-06','2017-04-07','2017-04-08','2017-04-09','2017-04-10',
                   '2017-04-11','2017-04-12','2017-04-13','2017-04-14','2017-04-15',
                   '2017-04-16','2017-04-17','2017-04-18','2017-04-19','2017-04-20',
                   '2017-04-21','2017-04-22','2017-04-23','2017-04-24','2017-04-25','2017-04-26'
            ]
        }],
        yAxis: {
            type: 'value',
            axisTick: {
                // 刻度与标签对齐
                alignWithLabel: true
            },
            splitLine: {
                lineStyle: {
                    type: 'solid'
                }
            },
            axisTick: {
                show: false
            }
        },
        series: [{
            name: '活跃用户',
            type: 'line',
            zlevel: 10,
            symbol: 'circle',
            symbolSize: 8,
            itemStyle: {
                normal: {
                    color: 'rgb(0, 153, 204)'
                }
            },
            data: [
                38,45,44,45,42,
                42,41,44,40,40,
                42,46,38,42,42,
                44,45,42,38,49,
                45,41,40,44,44,
                44,46,39,44,39,43
            ]
        }, {
            name: '活跃用户(均值)',
            type: 'line',
            symbol: 'circle',
            symbolSize: 8,
            itemStyle: {
                normal: {
                    color: 'rgb(204, 204, 204)'
                }
            },
            data: [
                44,43,43,43,42,
                42,41,42,41,41,
                40,41,41,41,41,
                44,42,42,41,43,
                43,43,42,42,43,
                43,43,42,43,42,42
            ]
        }, ]
    };
    return option;
}

const getOption4 = () => {
    const option = {
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            bottom: '20',
            data: ['2017-04-26', '2017-04-19']
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '15%',
            containLabel: true
        },
        xAxis: [{
            type: 'category',
            axisLabel: {
                interval: 1
            },
            splitLine: {
                show: true,
                lineStyle: {
                    type: 'solid'
                },
                interval: 1
            },
            boundaryGap: false,
            data: ['0:00', '1:00', '2:00', '3:00', '4:00', '5:00', '6:00',
                   '7:00', '8:00', '9:00', '10:00', '11:00', '12:00', '13:00',
                   '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00',
                   '21:00', '22:00', '23:00', '24:00']
        }],
        yAxis: {
            type: 'value',
            axisTick: {
                // 刻度与标签对齐
                alignWithLabel: true
            },
            splitLine: {
                lineStyle: {
                    type: 'solid'
                }
            },
            axisTick: {
                show: false
            }
        },
        series: [{
            name: '2017-04-26',
            type: 'line',
            zlevel: 10,
            symbol: 'circle',
            symbolSize: 8,
            itemStyle: {
                normal: {
                    color: 'rgb(0, 153, 204)'
                }
            },
            data: [2,2,1,0,0,2,3,6,3,1,3,3,2,2,3,2,3,0,0,2,3,5,4,4]
        }, {
            name: '2017-04-19',
            type: 'line',
            symbol: 'circle',
            symbolSize: 8,
            itemStyle: {
                normal: {
                    color: 'rgb(204, 204, 204)'
                }
            },
            data: [3,3,0,0,0,3,8,3,3,4,3,1,1,3,3,2,0,2,1,3,7,1,3,3]
        }, ]
    };
    return option;
}

export { getOption1, getOption2, getOption3, getOption4 }
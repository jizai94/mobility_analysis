var webpack = require('webpack');
var path = require('path');
var OpenBrowserPlugin = require('open-browser-webpack-plugin');
module.exports = {
	entry: {
		app: [
				'webpack/hot/dev-server',
				'webpack-dev-server/client?http://localhost:8080',
				'./entry.js'
			],
		libs: ['react', 'react-dom', 'react-router', 'redux', 'react-redux', 'redux-logger']
	},
	output: {
		path: path.resolve(__dirname),
		filename: 'app.js'
	},
	module: {
		loaders: [{
			test: /\.js$/,
			exclude: /node_modules/,
			loader: 'babel-loader',
			query: {
				presets: ['es2015', 'react']
			}
		}, {
			test: /\.css$/,
			loader: 'style-loader!css-loader',
		}, {
			test: /\.(scss|sass)$/,
			loader: 'style-loader!css-loader!sass-loader',
		}, {
			test: /\.(png|jpg)$/,
			loader: 'url-loader?limit=8192'
		}]
	},
	plugins: process.env.NODE_ENV === 'production' ? [
		new webpack.optimize.DedupePlugin(),
		new webpack.optimize.OccurrenceOrderPlugin(),
		new webpack.optimize.UglifyJsPlugin()
	] : [
			new webpack.HotModuleReplacementPlugin(),
			new OpenBrowserPlugin({ url: 'http://localhost:8080' }),
			new webpack.optimize.CommonsChunkPlugin('libs', 'libs/libs.js')
		]
}
import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import '../style/header.scss'
import { Button } from 'antd'

class Header extends Component{
  render(){
        return (
        <header>
              <img className="logo" src="./images/logo.png"/>
          </header>
        )
    }
}

export default Header
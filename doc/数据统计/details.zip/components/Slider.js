import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import '../style/slider.scss'
import { Link } from 'react-router'

class Slider extends Component{
	constructor(props){
		super(props)
	}
	handleClick(e){
		const target = e.target
		const next = target.nextSibling

	    if (target.getAttribute('data-state') == '0') {
	      target.classList.add('active')
	      target.setAttribute('data-state', '1')
	      next.style.display = "block"
	    } else {
	      target.classList.remove('active')
	      target.setAttribute('data-state', '0')
	      next.style.display = "none"
	    }
	}
	render(){
        return (
	    	<div id="sidebar">
	        	<div className="sideContainer">
	                <div className="smenu">
	                	<div className="grp">
	                    	<div className="tt" data-state='0' onClick={e=>this.handleClick(e)}>今日实时</div>
	                        <ul>
	                        	{/*<li><a href="#/todayDetails">今日实时</a></li>*/}
	                        	<li><Link to="todayDetails">今日实时</Link></li>
	                        </ul>
	                    </div>
	                    <div className="grp">
	                    	<div className="tt" data-state='0' onClick={e=>this.handleClick(e)}>基本统计</div>
	                        <ul>
	                        	<li><Link to="applicationTrend">应用趋势</Link></li>
	                            <li><Link to="timeAnalysis">时段分析</Link></li>
	                            <li><Link to="version">版本分布</Link></li>
	                            <li><Link to="region">地域分析</Link></li>
	                        </ul>
	                    </div>
	                    <div className="grp">
	                    	<div className="tt" data-state='0' onClick={e=>this.handleClick(e)}>用户行为</div>
	                        <ul>
	                        	<li><a href="#">启动次数</a></li>
	                            <li><a href="#">使用时长</a></li>
	                            <li><a href="#">页面路径分析</a></li>
	                            <li><a href="#">关键漏斗</a></li>
	                            <li><a href="#">自定义事件</a></li>
	                        </ul>
	                    </div>
	                    <div className="grp">
	                    	<div className="tt" data-state='0' onClick={e=>this.handleClick(e)}>活跃及留存</div>
	                        <ul>
	                        	<li><a href="#">用户活跃度</a></li>
	                            <li><a href="#">用户留存</a></li>
	                            <li><a href="#">页面留存</a></li>
	                        </ul>
	                    </div>
	                    <div className="grp">
	                    	<div className="tt" data-state='0' onClick={e=>this.handleClick(e)}>渠道分析</div>
	                        <ul>
	                        	<li><a href="#">渠道效果</a></li>
	                        </ul>
	                    </div>
	                    <div className="grp">
	                    	<div className="tt" data-state='0' onClick={e=>this.handleClick(e)}>终端与网络</div>
	                        <ul>
	                        	<li><a href="#Brand">品牌分析</a></li>
	                            <li><a href="#">机型分布</a></li>
	                            <li><a href="#">操作系统版本</a></li>
	                            <li><a href="#">分辨率</a></li>
	                            <li><a href="#">网络与运营商</a></li>
	                        </ul>
	                    </div>
	                    <div className="grp">
	                    	<div className="tt" data-state='0' onClick={e=>this.handleClick(e)}>Crash分析</div>
	                        <ul>
	                        	<li><a href="#">实行Crash</a></li>
	                            <li><a href="#">Crash趋势</a></li>
	                            <li><a href="#">Crash详情</a></li>
	                        </ul>
	                    </div>
	                    <div className="grp">
	                    	<div className="tt" data-state='0' onClick={e=>this.handleClick(e)}>新版Crash分析</div>
	                        <ul>
	                        	<li><a href="#">Crash列表</a></li>
	                            <li><a href="#">Crash趋势</a></li>
	                            <li><a href="#">符号化文件管理</a></li>
	                        </ul>
	                    </div>
	                    <div className="grp">
	                    	<div className="tt" data-state='0' onClick={e=>this.handleClick(e)}>性能分析</div>
	                        <ul>
	                        	<li><a href="#">请求性能</a></li>
	                            <li><a href="#">网络异常</a></li>
	                            <li><a href="#">网络性能地域分析</a></li>
	                            <li><a href="#">自定义性能事件分析</a></li>
	                            <li><a href="#">自定义性能事件地域分析</a></li>
	                        </ul>
	                    </div>
	                    <div className="grp">
	                    	<div className="tt" data-state='0' onClick={e=>this.handleClick(e)}>管理设置</div>
	                        <ul>
	                        	<li><a href="#">自定义事件管理</a></li>
	                            <li><a href="#">参数管理</a></li>
	                            <li><a href="#">渠道管理</a></li>
	                        </ul>
	                    </div>
	                </div>
	            </div>
	        </div>
        )
    }
}

export default Slider
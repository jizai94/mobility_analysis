import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import { Router, Route, IndexRoute, hashHistory } from 'react-router'
import Header from './Header'
import Slider from './Slider'
import '../style/main.scss'

class Layout extends Component{
	render() {
		return (
		<div className="content" id="content" style={{margin:0,padding:0}}>
			<Header />
			<Slider />
			<div className="container" id="container">
				{this.props.children}
			</div>
		</div>
	)
	}
}

export default Layout
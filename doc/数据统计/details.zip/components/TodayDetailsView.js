import React, { Component } from 'react'
import '../style/todayDetails.scss'
import { Button, Icon, Select, Tooltip, DatePicker } from 'antd'
import moment from 'moment';
import ReactEcharts from 'echarts-for-react'
import { getOption1, getOption2 } from '../option/todayDetails'
const { Option, OptGroup } = Select;

export default class TodayDetails extends Component {
	constructor(props){
		super(props);
		this.state = {}
	}
	handleClick(e) {
		const childs = e.currentTarget.parentNode.parentNode.childNodes
		for(let i = 0; i < childs.length; i++){
			childs[i].classList.remove('active')
		}
		e.currentTarget.parentNode.classList.add('active')
	}
	componentDidMount() {
		let now = () => {
			let date = new Date(),
    		checkTime = (i) => {
    			if (i<10) {
    				i="0" + i
    			}
  				return i
    		},
    		year = checkTime(date.getFullYear()),
    		month = checkTime(date.getMonth() + 1),
    		day = checkTime(date.getDate()),
    		hour = checkTime(date.getHours()),
    		min = checkTime(date.getMinutes()),
    		sec = checkTime(date.getSeconds());
    		document.getElementsByClassName('time')[0].innerHTML = `${year}-${month}-${day} ${hour}:${min}:${sec}`;
    		/*this.setState({
    			time: `${year}-${month}-${day} ${hour}:${min}:${sec}`,
    		})*/
		}
		setInterval(now, 1000);
  	}
	render() {
		const date = new Date(),
			  year = date.getFullYear(),
			  month = (date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1),
			  day = (date.getDate() - 1) < 10 ? '0' + (date.getDate() - 1) : (date.getDate() - 1),
			  yesterday = `${year}-${month}-${day}`;
		return (
			<div className="todayDetails">
				<div className="row1">
					<div>
						<h5 className="title">
							今日实时
							<Tooltip placement="right" title="今日实时">
        						<Icon type="question-circle" />
      						</Tooltip>
						</h5>
						<h5 className="time"></h5>
						<Select
    						showSearch
    						style={{ width: 150, float: 'right' }}
    						defaultValue="all"
  						>
    						<Option value="all">全部版本</Option>
    						<Option value="6.8">6.8</Option>
    						<Option value="6.7">6.7</Option>
  						</Select>
					</div>
				</div>
				<div className="row2">
					<ul className="nav">
						<li className="active">
							<a onClick={e => this.handleClick(e)}>
								<span className="fz16">活跃用户</span><br/>
								<span className="fz24">999,086</span><br/>
								<span className="fz12">比昨日同期：</span><span className="fz12">12%</span>
								<Icon type="arrow-up" className="arrow-up"/><br/>
								{/*<span className="panglyphicon glyphicon-arrow-up"></span>*/}
								<span className="fz12">比上周同期：</span><span className="fz12">-20%</span>
								<Icon type="arrow-down" className="arrow-down"/><br/>
							</a>
						</li>
						<li>
							<a onClick={e => this.handleClick(e)}>
								<span className="fz16">新增用户</span><br/>
								<span className="fz24">55,998</span><br/>
								<span className="fz12">比昨日同期：</span><span className="fz12">12%</span>
								<Icon type="arrow-up" className="arrow-up"/><br/>
								{/*<span className="panglyphicon glyphicon-arrow-up"></span>*/}
								<span className="fz12">比上周同期：</span><span className="fz12">-20%</span>
								<Icon type="arrow-down" className="arrow-down"/><br/>
							</a>
						</li>
						<li>
							<a onClick={e => this.handleClick(e)}>
								<span className="fz16">登陆会员</span><br/>
								<span className="fz24">9,809</span><br/>
								<span className="fz12">比昨日同期：</span><span className="fz12">12%</span>
								<Icon type="arrow-up" className="arrow-up"/><br/>
								{/*<span className="panglyphicon glyphicon-arrow-up"></span>*/}
								<span className="fz12">比上周同期：</span><span className="fz12">-20%</span>
								<Icon type="arrow-down" className="arrow-down"/><br/>
							</a>
						</li>
						<li>
							<a onClick={e => this.handleClick(e)}>
								<span className="fz16">新注册会员</span><br/>
								<span className="fz24">89,000</span><br/>
								<span className="fz12">比昨日同期：</span><span className="fz12">12%</span>
								<Icon type="arrow-up" className="arrow-up"/><br/>
								{/*<span className="panglyphicon glyphicon-arrow-up"></span>*/}
								<span className="fz12">比上周同期：</span><span className="fz12">-20%</span>
								<Icon type="arrow-down" className="arrow-down"/><br/>
							</a>
						</li>
						<li>
							<a onClick={e => this.handleClick(e)}>
								<span className="fz16">启动次数</span><br/>
								<span className="fz24">66,889</span><br/>
								<span className="fz12">比昨日同期：</span><span className="fz12">12%</span>
								<Icon type="arrow-up" className="arrow-up"/><br/>
								{/*<span className="panglyphicon glyphicon-arrow-up"></span>*/}
								<span className="fz12">比上周同期：</span><span className="fz12">-20%</span>
								<Icon type="arrow-down" className="arrow-down"/><br/>
							</a>
						</li>
					</ul>
				</div>
				<div className="row3">
					<div>
						<h6 className="fz14">区间分布</h6>
						<div>
							<h6 className="fz14">时间轴：</h6>
							<Select
    							showSearch
    							style={{ float: 'right' }}
    							defaultValue="hour"
  							>
    							<Option value="hour">小时</Option>
    							<Option value="minu">分钟</Option>
  							</Select>
						</div>
						<div>
							<h6 className="fz14">对比：</h6>
							<DatePicker size="default" defaultValue={moment(yesterday, 'YYYY-MM-DD')} />
						</div>
						<ReactEcharts
                        	option={getOption1()} 
                        	style={{height: '435px', width: '100%', marginTop: '5px'}} 
                        	className='react_for_echarts' 
                        />
					</div>
				</div>
				<div className="row4">
					<ul className="nav">
						<li className="active">
							<a className="fz12" onClick={e => this.handleClick(e)}>活跃用户</a>
						</li>
						<li>
							<a className="fz12" onClick={e => this.handleClick(e)}>新增用户</a>
						</li>
						<li>
							<a className="fz12" onClick={e => this.handleClick(e)}>登陆会员</a>
						</li>
						<li>
							<a className="fz12" onClick={e => this.handleClick(e)}>新注册会员</a>
						</li>
						<li>
							<a className="fz12" onClick={e => this.handleClick(e)}>启动次数</a>
						</li>
					</ul>
				</div>
				<div className="row5">
					<div>
						<h6 className="fz14">24小时累计</h6>
						<div>
							<h6 className="fz14">对比：</h6>
							<DatePicker size="default" defaultValue={moment(yesterday, 'YYYY-MM-DD')} />
						</div>
						<ReactEcharts
                        	option={getOption2()} 
                        	style={{height: '450px', width: '100%'}} 
                        	className='react_for_echarts' 
                        />
					</div>
				</div>
			</div>
		)
	}
}
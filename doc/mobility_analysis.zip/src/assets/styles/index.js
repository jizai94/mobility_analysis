'use strict'

import 'nprogress/nprogress.css'

import './public/core.scss'
import './layouts'
import './pages/common.scss'

import './loading2.scss'
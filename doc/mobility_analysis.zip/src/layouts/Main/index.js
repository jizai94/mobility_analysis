import connect from 'STORE/connect'
import MainView from './MainView'

export default connect(

  state => ({
  }),

  {},
  
  MainView
)

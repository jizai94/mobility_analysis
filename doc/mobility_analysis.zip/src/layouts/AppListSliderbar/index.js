import connect from 'STORE/connect'
import SidebarView from './SidebarView'

export default connect(

  state => ({
  }),

  {},
  
  SidebarView
)



export default {
	'todayDetails':0,

	'applicationTrend':1,
	'timeAnalysis':1,
	'version':1,
	'region':1,

	'startCount':2,
	'useTime':2,
	'pagePath':2,
	'event':2,

	'userActivity':3,
	'userRetain':3,
	'pageRetain':3,

	'Brand':5,
	'modelAnalysis':5,
	'osVersion':5,
	'resolution':5,
	'netAndOperator':5,

	'realCrash':6,
	'crashTrend':6,
	'crashDetail':6,

	'eventManage':9,
	'paramsManage':9
}



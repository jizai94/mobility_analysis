import connect from 'STORE/connect'
import MainView from './AppListMainView'

export default connect(

  state => ({
  }),

  {},
  
  MainView
)

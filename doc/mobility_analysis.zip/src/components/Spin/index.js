import SpinView from './SpinView'

export default SpinView

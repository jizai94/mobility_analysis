import InputSearchView from './InputSearchView'

export default InputSearchView

import RoleTreeView from './RoleTreeView'

export default RoleTreeView

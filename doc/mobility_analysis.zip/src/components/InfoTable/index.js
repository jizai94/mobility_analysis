import InfoTableView from './InfoTableView'

export default InfoTableView

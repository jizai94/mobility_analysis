import connect from 'STORE/connect'
import ParamsManageView from './ParamsManageView'

export default connect(
	state => ({

	}),

	{},
	
	ParamsManageView
)
import connect from 'STORE/connect'
import PageRetainView from './PageRetainView'

export default connect(
	state => ({

	}),

	{},
	
	PageRetainView
)
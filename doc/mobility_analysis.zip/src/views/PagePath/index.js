import connect from 'STORE/connect'
import PagePath from './PagePath'

export default connect(
	state => ({

	}),
	{},
	PagePath
)
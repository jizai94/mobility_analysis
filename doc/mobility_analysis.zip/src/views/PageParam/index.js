import connect from 'STORE/connect'
import PageParam from './PageParam'

export default connect(
	state => ({

	}),
	{},
	PageParam
)
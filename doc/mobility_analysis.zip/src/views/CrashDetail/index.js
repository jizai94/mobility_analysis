/**
 * Created by Alex on 2017/5/3.
 */
import connect from 'STORE/connect'
import CrashDetail from './CrashDetail'

export default connect(
    state => ({

    }),
    {},
    CrashDetail
)
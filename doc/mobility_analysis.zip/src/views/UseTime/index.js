/**
 * Created by Alex on 2017/5/8.
 */
import connect from 'STORE/connect'
import UseTime from './UseTime'

export default connect(
  state => ({

  }),
  {},
  UseTime
)
